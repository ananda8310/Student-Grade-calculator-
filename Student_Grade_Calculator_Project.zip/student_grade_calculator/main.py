# Student Grade Calculator
# A beginner-friendly Python mini project.

def get_mark(subject):
    while True:
        try:
            mark = float(input(f"Enter marks for {subject} (0-100): "))
            if 0 <= mark <= 100:
                return mark
            print("Please enter a mark between 0 and 100.")
        except ValueError:
            print("Invalid input. Please enter a number.")

def calculate_grade(percentage):
    if percentage >= 90:
        return "A+"
    elif percentage >= 80:
        return "A"
    elif percentage >= 70:
        return "B"
    elif percentage >= 60:
        return "C"
    elif percentage >= 50:
        return "D"
    else:
        return "F"

def main():
    print("=" * 40)
    print("       STUDENT GRADE CALCULATOR")
    print("=" * 40)

    name = input("Enter student name: ").strip()
    while not name:
        print("Name cannot be empty.")
        name = input("Enter student name: ").strip()

    subjects = ["Python", "Mathematics", "DBMS", "English", "Computer Science"]
    marks = []

    for subject in subjects:
        marks.append(get_mark(subject))

    total = sum(marks)
    average = total / len(subjects)
    percentage = (total / (len(subjects) * 100)) * 100
    grade = calculate_grade(percentage)
    result = "PASS" if all(mark >= 35 for mark in marks) else "FAIL"

    print("\n" + "=" * 40)
    print("             RESULT")
    print("=" * 40)
    print(f"Student Name : {name}")
    for subject, mark in zip(subjects, marks):
        print(f"{subject:<18}: {mark:g}")
    print("-" * 40)
    print(f"Total Marks  : {total:g} / 500")
    print(f"Average      : {average:.2f}")
    print(f"Percentage   : {percentage:.2f}%")
    print(f"Grade        : {grade}")
    print(f"Result       : {result}")
    print("=" * 40)

if __name__ == "__main__":
    main()
