# Student Grade Calculator

## About the Project
Student Grade Calculator is a beginner-level Python mini project. It accepts a student's name and marks in five subjects, then calculates the total, average, percentage, grade, and pass/fail result.

## Features
- Takes the student's name as input.
- Accepts marks for five subjects.
- Checks that marks are between 0 and 100.
- Calculates total, average, and percentage.
- Displays a grade and pass/fail status.

## Technologies Used
- Python 3
- Built-in Python functions only (no extra libraries required)

## How to Run
1. Install Python 3.
2. Download or clone this repository.
3. Open a terminal in the project folder.
4. Run:

```bash
python main.py
```

On some systems, use:

```bash
python3 main.py
```

## Subjects
- Python
- Mathematics
- DBMS
- English
- Computer Science

## Grade Criteria
| Percentage | Grade |
|---|---|
| 90–100 | A+ |
| 80–89.99 | A |
| 70–79.99 | B |
| 60–69.99 | C |
| 50–59.99 | D |
| Below 50 | F |

A student passes only if they score at least 35 marks in every subject.

## Author
Student Mini Project – Python Internship Module 02
